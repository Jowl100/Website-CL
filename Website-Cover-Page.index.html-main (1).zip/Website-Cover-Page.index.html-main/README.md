# Website-Cover-Page
A visually appealing brief cover page

THE WEBSITE IS STILL IN PROGRESS 😊
FYI: The React text section was used for design purposes. 

About

This page is a simple but friendly design, made with the intentions of being used as a one click covering letter.

Languages
HTML5; CSS3.

Features

-	Visually appeasing cover section with name and title, this part works well with gradients so please feel free to try one, one I have toyed with: background: linear-gradient(#e66465, #9198e5);
-	About me section with link to add a profile icon / image. 
-	Skills section with centralised text and icons
-	Contact me button, set up to go open an email with your email address.
-	Website buttons for your: GitHub, LinkedIn, Website and or portfolio. 

